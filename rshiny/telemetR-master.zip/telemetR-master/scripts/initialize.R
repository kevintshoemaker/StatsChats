# INITIALIZATION SCRIPT, RUN FOR NEW USER.
install.packages("leaflet")
install.packages("DT")
install.packages("data.table")
install.packages("shiny")